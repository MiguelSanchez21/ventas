<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Cotizacion>
 */
class CotizacionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            //
            //idusuario:
            'user_id' => $this->faker->numberBetween(1, 10),
            //idcliente:
            'customer_id' => $this->faker->numberBetween(1, 10),
            //fecha de cotizacion:
            'date' => $this->faker->date(),
            //fecha estimada de viaje:
            'estimated_date' => $this->faker->date(),
            //origen:
            'origin' => $this->faker->city(),
            //destino:
            'destination' => $this->faker->city(),
            //peso de carga:
            'weight' => $this->faker->numberBetween(1, 100),
            //costo de viaje:
            'cost' => $this->faker->numberBetween(1, 100),
            //id estatus:
            'status_id' => $this->faker->numberBetween(1, 3),

        ];
    }
}
