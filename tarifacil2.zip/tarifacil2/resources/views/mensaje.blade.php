@extends('template')

@section('content')
    <p> {{ $mensaje }} </p>

    <div class="d-flex justify-content-center">
        <a href="{{ route($ruta) }}" class="btn btn-primary">Regresar</a>

    </div>
@endsection