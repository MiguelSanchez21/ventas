@extends('template')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 bg-image" style="background-image: url('{{ asset('images/cotizacion.jpg') }}'); background-size: cover; height: 100vh;">
            </div>
            <div class="col-md-6">
                <h2 class="mb-4">Crear Cotización</h2>
                <form action="{{ route('cotizacion.store') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label for="customer_search" class="form-label">Cliente</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="customer_search" name="customer_search" placeholder="Buscar Cliente...">
                            <button type="button" class="btn btn-outline-secondary" onclick="searchCustomer()">
                                <i class="fas fa-search"></i>
                            </button>
                            <button type="button" class="btn btn-success" onclick="addCustomer()">
                                <i class="fas fa-plus"></i> 
                            </button>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="estimated_date" class="form-label">Fecha Estimada de Viaje</label>
                        <input type="date" class="form-control" id="estimated_date" name="estimated_date">
                    </div>
                    <div><label for="origin_state" class="form-label">Origen</label></div>
                    <div class="d-flex">
                        <div class="mb-3 me-3">
                            <input type="text" class="form-control" id="origin_state" name="origin_state" placeholder="Estado">
                        </div>
                        <div class="mb-3 me-3">
                            <input type="text" class="form-control" id="origin_city" name="origin_city" placeholder="Ciudad">
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="origin_neighborhood" name="origin_neighborhood" placeholder="Colonia">
                        </div>
                    </div>

                    <!-- Repite el mismo formato para el destino -->
                    <div>
                        <label for="destination_state" class="form-label">Destino</label>
                    </div>
                         
                    <div class="d-flex">
                        <div class="mb-3 me-3">
                            <input type="text" class="form-control" id="destination_state" name="destination_state" placeholder="Estado">
                        </div>
                        <div class="mb-3 me-3">
                            <input type="text" class="form-control" id="destination_city" name="destination_city" placeholder="Ciudad">
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="destination_neighborhood" name="destination_neighborhood" placeholder="Colonia">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="weight" class="form-label">Peso de Carga</label>
                        <input type="text" class="form-control" id="weight" name="weight">
                    </div>

                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="kilometers" class="form-label">Distancia (kms)</label>
                                <span class="form-control" id="kilometers" name="kilometers" readonly> ....</span>
                            </div>
                            <div class="col-md-6">
                                <label for="gasoline" class="form-label">Combustible (Diesel)</label>
                                <span class="form-control" id="gasoline" name="gasoline" readonly> ... </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="cost" class="form-label">Costo de Viaje</label>
                        <div class="row align-items-center">
                            <div class="col-9">
                                <div class="rounded-pill bg-success text-white p-2 text-center">
                                    <span id="cost" style="font-size: 75%;">...</span>
                                </div>
                            </div>
                            <div class="col-3">
                                <button type="button" class="btn btn-success">Calcular</button>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="" class="btn btn-danger order-1">Cancelar</a>
                        <button type="submit" class="btn btn-primary order-2">Generar</button>
                    </div>          
                </form>
            </div>
        </div>
    </div>
@endsection


<script>
    document.getElementById('customer_search').addEventListener('clik', function()){
        
    }
</script>