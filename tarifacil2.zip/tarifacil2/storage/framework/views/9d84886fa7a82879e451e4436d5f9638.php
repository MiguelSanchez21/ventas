

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Mis Choferes</h2>
    <form class="d-flex" action="<?php echo e(route('drivers.index')); ?>" method="GET">
        <input class="form-control me-2" type="search" placeholder="Buscar Chofer..." name="searchQuery" value="<?php echo e($searchQuery); ?>">
        <button class="btn btn-outline-secondary" type="submit">
            <i class="fas fa-search"></i> <!-- Icono de búsqueda -->
        </button>
    </form>
    <a href="<?php echo e(route('driver.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> <!-- Icono de añadir -->
    </a>
</div>

    <table class="table mt-4">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Dirección</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($driver->id); ?></td>
                    <td><?php echo e($driver->name); ?></td>
                    <td><?php echo e($driver->address); ?></td>
                    <td><?php echo e($driver->phone); ?></td>
                    <td>
                        <form action="<?php echo e(route('drivers.destroy', $driver->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('¿Estás seguro de que deseas eliminar al chofer <?php echo e($driver-> name); ?>?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <!--boton de eliminar con icono: -->
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash-alt"></i> <!-- Icono de eliminar -->
                            </button>
                        </form>
                        
                        <a href="<?php echo e(route('driver.edit', $driver)); ?>" class="btn btn-warning">
                            <i class="fas fa-edit"></i> <!-- Icono de editar -->
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <!-- Pagination Section -->
    <div class="row">
        <div class="col-md-12 text-center mt-4">
            <div class="pagination" style="font-size: 14px;">
                <?php echo e($drivers->appends(['searchQuery' => $searchQuery])->links('pagination::simple-bootstrap-4')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tarifacil2\resources\views/Choferes/ver_choferes.blade.php ENDPATH**/ ?>