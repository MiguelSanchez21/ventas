

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-md-6 bg-image" style="background-image: url('<?php echo e(asset('images/trailer.png')); ?>'); background-size: cover; height: 100vh;">
            </div>
            <div class="col-md-6 d-flex align-items-center">
                <div class="container">
                    <h2 class="mb-4">Crear Trailer</h2>
                    <form action="<?php echo e(route('trailer.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="economico" class="form-label">Número Económico</label>
                            <input type="text" class="form-control" id="economico" name="economico" value="">
                        </div>
                        <div class="mb-3">
                            <label for="size" class="form-label">Tamaño de Caja</label>
                            <input type="text" class="form-control" id="size" name="size" value="">
                        </div>

                        <div class="mb-3">
                            <label for="chofer" class="form-label">Chofer</label>
                            <select class="form-select" id="chofer" name="chofer">
                                <option value="">Selecciona un chofer</option>
                                <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chofer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($chofer->id); ?>"><?php echo e($chofer->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('trailers.index')); ?>" class="btn btn-danger">
                                <i class="fas fa-times"></i> Cancelar
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Guardar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tarifacil2\resources\views/Trailers/crear_trailers.blade.php ENDPATH**/ ?>