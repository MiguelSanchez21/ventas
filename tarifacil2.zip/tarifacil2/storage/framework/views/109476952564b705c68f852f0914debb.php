

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Trailers</h2>
        <form class="d-flex" action="<?php echo e(route('trailers.index')); ?>" method="GET">
            <input class="form-control me-2" type="search" placeholder="Buscar Trailer..." name="searchQuery" value="<?php echo e($searchQuery); ?>">
            <button class="btn btn-outline-secondary" type="submit">
                <i class="fas fa-search"></i>
            </button>
        </form>
        <a href="<?php echo e(route('trailer.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i>
        </a>
    </div>
    <table class="table mt-4">
        <thead>
            <tr>
                <th>ID</th>
                <th>Número Económico</th>
                <th>Tamaño</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $trailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trailer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($trailer->id); ?></td>
                    <td><?php echo e($trailer->economic_number); ?></td>
                    <td><?php echo e($trailer->size); ?></td>
                    <td>
                        <div class="btn-group" role="group">
                            <form action="<?php echo e(route('trailers.destroy', $trailer->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar al trailer <?php echo e($trailer-> economic_number); ?>?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                            <a href="<?php echo e(route('trailer.edit', $trailer)); ?>" class="btn btn-warning">
                                <i class="fas fa-edit"></i>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<!-- Pagination Section -->
<div class="row">
    <div class="col-md-12 text-center mt-4">
        <div class="pagination" style="font-size: 14px;">
            <?php echo e($trailers->appends(['searchQuery' => $searchQuery])->links('pagination::simple-bootstrap-4')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tarifacil2\resources\views/Trailers/ver_trailers.blade.php ENDPATH**/ ?>