

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('trailers.update', $trailer)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="nombre" class="form-label">Numero economico</label>
            <input type="text" class="form-control" id="economico" name="economico" 
                value="<?php echo e($trailer->economic_number); ?>">
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Tamaño</label>
            <input type="text" class="form-control" id="tamaño" name="tamaño"
                value="<?php echo e($trailer->size); ?>">
        </div>
        <div class="d-flex justify-content-between">
            <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-danger">Cancelar</a>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tarifacil2\resources\views/Trailers/editar_trailers.blade.php ENDPATH**/ ?>