

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-md-6 bg-image" style="background-image: url('<?php echo e(asset('images/chofer.jpg')); ?>'); background-size: cover; height: 100vh;">
            </div>
            <div class="col-md-6 d-flex align-items-center">
                <div class="container">
                    <h2 class="mb-4">Crear Chofer</h2>
                    <form action="<?php echo e(route('driver.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre del Chofer</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" value="">
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Teléfono</label>
                            <input type="text" class="form-control" id="phone" name="telefono" value="">
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">Dirección</label>
                            <input type="text" class="form-control" id="address" name="direccion" value="">
                        </div>
                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('drivers.index')); ?>" class="btn btn-danger">Cancelar</a>
                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tarifacil2\resources\views/Choferes/crear_chofer.blade.php ENDPATH**/ ?>