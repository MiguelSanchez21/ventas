

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Clientes</h2>
    <form class="d-flex" action="<?php echo e(route('customers.index')); ?>" method="GET" >
            <input type="search" class="form-control me-2" placeholder="Buscar cliente..." name="searchQuery" value="<?php echo e($searchQuery); ?>">
            <button class="btn btn-outline-secondary" type="submit">
                <i class="fas fa-search"></i> <!-- Icono de búsqueda -->
            </button>
    </form>
    <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> <!-- Icono de añadir -->
    </a>
</div>



<table class="table mt-4">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>RFC</th>
            <th>Dirección</th>
            <th>Teléfono</th>
            <th>Correo</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($customer->id); ?></td>
                <td><?php echo e($customer->name); ?></td>
                <td><?php echo e($customer->rfc); ?></td>
                <td><?php echo e($customer->address); ?></td>
                <td><?php echo e($customer->phone); ?></td>
                <td><?php echo e($customer->email); ?></td>
                <td>
                    <form action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('¿Estás seguro de que deseas eliminar al cliente <?php echo e($customer-> name); ?>?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> <!-- Icono de eliminar -->
                        </button>
                    </form>
                    
                    <a href="<?php echo e(route('customer.edit', $customer)); ?>" class="btn btn-warning">
                        <i class="fas fa-edit"></i> <!-- Icono de editar -->
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!-- Pagination Section -->
<div class="row">
    <div class="col-md-12 text-center mt-4">
        <div class="pagination" style="font-size: 14px;">
            <?php echo e($customers->appends(['searchQuery' => $searchQuery])->links('pagination::simple-bootstrap-4')); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tarifacil2\resources\views/Clientes/ver_clientes.blade.php ENDPATH**/ ?>