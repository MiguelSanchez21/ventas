<?php

namespace App\Http\Controllers;

use App\Models\Trailer;
use Illuminate\Http\Request;
use App\Models\Driver;

class TrailerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $trailer = new Trailer();
        $trailer->economic_number = $request->economico;
        $trailer->size = $request->size;
        $trailer->save();
        
        return view('mensaje', [
            'mensaje' => 'Trailer ' . $trailer->economic_number . ' creado con éxito',
            'ruta' => 'trailers.index',
            
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Trailer $trailer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Trailer $trailer)
    {
        //
        $trailer->economic_number = $request->economic;
        $trailer->size = $request->tamaño;
        $trailer->save();

        return view('mensaje', [
            'mensaje' => 'Trailer '. $trailer->economic_number.' actualizado correctamente ' ,
            'ruta' => 'trailers.index',
        ],);
        
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Trailer $trailer)
    {
        //
        $trailer->delete();
        return view('mensaje', [
            'mensaje' => 'Trailer eliminado correctamente ' ,
            'ruta' => 'trailers.index',
        ],);
    }

    public function verTrailers(Request $request)
    {
        $searchQuery = $request->input('searchQuery', '');
        $trailers = Trailer::where('economic_number', 'like', "%$searchQuery%")
            ->orWhere('size', 'like', "%$searchQuery%")
            ->paginate(4);
    return View('Trailers.ver_trailers', ['trailers' => $trailers,'searchQuery' => $searchQuery,]);
    }

    public function editar(Trailer $trailer)
    {
        
        return View ('Trailers.editar_trailers',
        ['trailer' => $trailer,
    ],);
    }

    public function create()
    {

        //query para obtener los choferes que no tienen remolque asignado:
        //$choferes = Driver::whereNull('trailer_id')->get();
        $choferes = Driver::all();

        //return View ('Trailers.crear_trailers', ['choferes' => $choferes,]);
        return View ('Trailers.crear_trailers', ['choferes' => $choferes,]);
    }
}
