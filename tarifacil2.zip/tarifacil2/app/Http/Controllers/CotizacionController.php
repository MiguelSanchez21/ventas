<?php

namespace App\Http\Controllers;

use App\Models\Cotizacion;
use Illuminate\Http\Request;

class CotizacionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $cotizacion = new Cotizacion();
        $user_id = $request->user_id;
        $customer_id = $request->customer_id;
        $date = $request->date;
        $estimated_date = $request->estimated_date;
        $origin = $request->origin;
        $destination = $request->destination;
        $weight = $request->weight;
        $cost = $request->cost;
        $status_id = '1';
        $cotizacion ->save();
        return view ('mensaje', 
        ['mensaje' => 'Precio '.$cotizacion->name.' creado con éxito',   
        'ruta'=>'prices.index',
        ]);

    }

    /**
     * Display the specified resource.
     */
    public function show(Cotizacion $price)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Cotizacion $price)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Cotizacion $price)
    {
        //
    }

    public function create ()
    {
        
        return view ('Cotizaciones.crear_cotizacion');
    }


}