<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/drivers', 'App\Http\Controllers\DriverController@verChoferes')
    ->name('drivers.index');
Route::get('/drivers/editar/{driver}', 'App\Http\Controllers\DriverController@editar')
    ->name('drivers.edit');
Route::put ('/drivers/actualizar/{driver}', 'App\Http\Controllers\DriverController@update')
    ->name('drivers.update');
Route::post('/drivers/guardar', 'App\Http\Controllers\DriverController@store')
    ->name('drivers.crear');
Route::delete('/drivers/eliminar/{driver}', 'App\Http\Controllers\DriverController@destroy')
    ->name('drivers.destroy');
Route::get('/drivers/create', 'App\Http\Controllers\DriverController@create')
    ->name('driver.create');
Route::get('/drivers/{driver}/edit', 'App\Http\Controllers\DriverController@editar')
    ->name('driver.edit');
Route::post('/drivers/guardar', 'App\Http\Controllers\DriverController@store')
    ->name('driver.store');

Route::get('/trailers', 'App\Http\Controllers\TrailerController@vertrailers')
    ->name('trailers.index');
Route::get('/trailers/editar/{trailer}', 'App\Http\Controllers\TrailerController@editar')    
    ->name('trailers.edit');
Route::put('/trailers/actualizar/{trailer}', 'App\Http\Controllers\TrailerController@update')
    ->name('trailers.update');
Route::post('/trailers/guardar', 'App\Http\Controllers\TrailerController@store')
    ->name('trailers.crear');
Route::delete('/trailers/eliminar/{trailer}', 'App\Http\Controllers\TrailerController@destroy')
    ->name('trailers.destroy');
Route::get('/trailers/create', 'App\Http\Controllers\TrailerController@create')
    ->name('trailer.create');
Route::get('/trailers/{trailer}/edit', 'App\Http\Controllers\TrailerController@editar')
    ->name('trailer.edit');
Route::post('/trailers/guardar', 'App\Http\Controllers\TrailerController@store')
    ->name('trailer.store');

Route::get('/customers', 'App\Http\Controllers\CustomerController@verclientes')
    ->name('customers.index');
Route::get('/customers/editar/{customer}', 'App\Http\Controllers\CustomerController@editar')
    ->name('customers.edit');
Route::put('/customers/actualizar/{customer}', 'App\Http\Controllers\CustomerController@update')
    ->name('customers.update');
Route::post('/customers/guardar', 'App\Http\Controllers\CustomerController@store')
    ->name('customers.crear');
Route::delete('/customers/eliminar/{customer}', 'App\Http\Controllers\CustomerController@destroy')
    ->name('customers.destroy');
Route::get('/customers/create', 'App\Http\Controllers\CustomerController@create')
    ->name('customer.create');
Route::get('/customers/{customer}/edit', 'App\Http\Controllers\CustomerController@editar')
    ->name('customer.edit');
Route::post('/customers/guardar', 'App\Http\Controllers\CustomerController@store')
    ->name('customer.store');

Route::get('/cotizaciones', 'App\Http\Controllers\CotizacionController@verprecios')
    ->name('cotizaciones.index');
Route::get('/cotizaciones/editar/{Cotizacion}', 'App\Http\Controllers\CotizacionController@editar')
    ->name('cotizaciones.edit');
Route::put('/cotizaciones/actualizar/{Cotizacion}', 'App\Http\Controllers\CotizacionController@update')
    ->name('cotizaciones.update');
Route::post('/cotizaciones/guardar', 'App\Http\Controllers\CotizacionController@store')
    ->name('cotizaciones.crear');
Route::delete('/cotizaciones/eliminar/{Cotizacion}', 'App\Http\Controllers\CotizacionController@destroy')
    ->name('cotizaciones.destroy');
Route::get('/cotizaciones/create', 'App\Http\Controllers\CotizacionController@create') 
    ->name('cotizacion.create');
Route::get('/cotizaciones/{Cotizacion}/edit', 'App\Http\Controllers\CotizacionController@editar')
    ->name('cotizacion.edit');
Route::post('/cotizaciones/guardar', 'App\Http\Controllers\CotizacionController@store')    
    ->name('cotizacion.store');

